# intermed
Desarrollo de la plataforma multimedia

# Estructura
Intermed

- apps
- - controllers
- - helpers
- - middleware
- - models
- - views
- - - Layouts

- config
- - route

- DB (migrations)

- node_modules
- - express
- - MySQL
- - express-handlebars
- - sequelize
- - handlebars

- public
- - assets
- - css
- - fonts
- - img
- - js
