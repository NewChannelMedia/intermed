﻿var models = require('../models');

exports.index = function (objects, req, res) {
    res.render('ubicacion', {title:'Carlos'});
};
